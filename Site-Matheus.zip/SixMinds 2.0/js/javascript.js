function Clicar()
{
    imagem.style.display="none";
}